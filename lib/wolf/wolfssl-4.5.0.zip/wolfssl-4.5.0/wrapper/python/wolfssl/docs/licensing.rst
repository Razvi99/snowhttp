.. include:: ../LICENSING.rst
