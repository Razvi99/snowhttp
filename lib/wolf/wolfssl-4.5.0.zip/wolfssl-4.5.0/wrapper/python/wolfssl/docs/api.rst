API Documentation
=================

.. module:: wolfssl

wrap_socket
-----------

.. autofunction:: wrap_socket

SSL/TLS Context
---------------

.. autoclass:: SSLContext
    :members:

SSL/TLS Socket
--------------

.. autoclass:: SSLSocket
    :members:
